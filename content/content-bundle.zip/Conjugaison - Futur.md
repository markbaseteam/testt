#allemand #conjugaison 

Pour le futur on utilise *werden* au présent puis l'infinitif.
ex: Ich *werde* einen Wagen *kaufen*.

![[Auxiliaires#Werden]]
