#allemand #politique #review 

| Kürzel  | Vollständiger Name                      | Politische Orientierung | Farbe |
| ------- | --------------------------------------- | ----------------------- | ----- |
| SPD     | Sozialdemokratische Partei Deutschlands | Mitte-Links             | 🔴    |
| CDU/CSU | Christlich Demokratische/Soziale Union  | Mitte-Rechts            | ⚫    |
| FDP     | Freie Demokratische Partei              | Rechts/Liberal          | 🟡    |
| AfD     | Alternativ für Deutschland              | Extrem Rechts           | 🔵    |
| Grünen  | Grünen                                  | Links/Ökologie          | 🟢    |
| Linke   | Die Linke                               | Links                   | 🔴    |
