#allemand #conjugaison #flashcards/allemand/conjugaison 

# Verbes Forts en -A

forme générale :: -a / -i(e) / -a
<!--SR:!2022-11-13,13,270-->
souffler  ::: blasen / bläst / blies / geblasen 
<!--SR:!2022-11-11,11,250!2022-11-12,12,263-->
faire cuire ::: braten / brät / briet / gebraten
<!--SR:!2022-11-12,12,250!2022-11-06,4,270-->
tomber ::: fallen* / fällt / fiel / gefallen
<!--SR:!2022-11-11,9,250!2022-11-23,15,270-->
attraper ::: fangen / fängt / fing / gefangen
<!--SR:!2022-11-05,3,210!2022-11-19,12,250-->
être accroché ::: halten / hält / hielt / gehalten
<!--SR:!2022-11-11,11,250!2022-11-14,14,263-->
laisser ::: lassen / lässt / ließ / gelassen
<!--SR:!2022-11-08,8,250!2022-11-21,14,270-->
courir ::: laufen* / läuft / lief / gelaufen
<!--SR:!2022-11-06,6,230!2022-11-06,4,270-->
conseiller ::: raten / rät / riet / geraten
<!--SR:!2022-11-12,12,270!2022-11-06,4,270-->
dormir ::: schlafen / schläft / schlief / geschlafen
<!--SR:!2022-11-13,13,250!2022-11-06,4,270-->

aller (voiture) ::: fahren / fährt / fuhr / gefahren
creuser ::: graben / gräbt / grub / gegraben
charger ::: laden / lädt / lud / geladen
créer ::: schaffen / schäft / schuf / geschaffen
frapper ::: schlagen / schlägt / schlug / geschlagen
porter ::: tragen / trägt / trug / getragen
grandir ::: wachsen / wächst / wuchs / gewachsen
laver ::: waschen / wäscht / wusch / gewaschen

manger ::: essen / isst / ass / gegessen
manger (animal) ::: fressen / frisst / frass / gefressen
donner ::: geben / gibt / gab / gegeben
guérir de ::: genesen / ? / genas / genesen
se passer ::: geschehen / geschieht / geschah / geschehen
lire ::: lesen / liest / las / gelesen
mesurer ::: messen / misst / mass / gemessen
voir ::: sehen / sieht / sah / gesehen
faire un pas ::: tretten / tritt / trat / getreten
oublier ::: vergessen / vergisst / vergass / vergessen

donner un ordre ::: befehlen / befiehlt / befahl / befohlen
casser ::: brechen / bricht / brach / gebrochen
recommander ::: empfehlen / empfiehlt / empfahl / empfohlen
avoir peur ::: erschrecken / erschrickt / erschrak / erschrocken
être valable ::: gelten / gilt / galt / gegolten
aider ::: hilfen / hilft / half / geholfen
prendre ::: nehmen / nimmt / nahm / genommen
parler ::: sprecheh / spricht / sprach / gesprochen
voler ::: stehlen / stiehlt / stahl / gestohlen
mourir ::: sterben / stirbt / starb / gestorben
rencontrer ::: treffer / trifft / traf / getroffen
briguer (faire de la publicité) ::: werben / wirbt / warb / geworben
jeter ::: werfen / wirft / warf / geworfen
