#flashcards/allemand/conjugaison 

# Terminaisons

ich spiel==e==
du spiel==st==
er spiel==t==
wir spiel==en==
ihr spiel==t==
sie spiel==en==
<!--SR:!2022-11-16,16,290!2022-11-27,20,294!2022-11-06,4,274!2022-11-06,4,274!2022-11-06,4,274!2022-11-06,4,274-->

# Auxiliaires

![[Auxiliaires]]


