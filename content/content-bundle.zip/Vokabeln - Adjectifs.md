#flashcards/allemand/vokabeln

zahlreich ::: nombreux
<!--SR:!2022-11-17,17,290!2022-11-04,4,272-->