
Pour le parfait on utilise *sein* ou *haben* au présent et le participe passé formé en ge-*racine*-t.

> Particules inséparables: ge-miss-zer-be-er-ent-emp-ver

[[Verbes Irréguliers]]
![[Auxiliaires#Sein]]
![[Auxiliaires#Haben]]

