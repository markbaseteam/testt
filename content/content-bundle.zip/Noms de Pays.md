[[Locatif & Directif]]
