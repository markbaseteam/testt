#allemand
![[Allemand/Vokabeln - Masculin]]![[Allemand/Vokabeln - Féminin]]![[Allemand/Vokabeln - Neutre]]![[Allemand/Vokabeln - Verbes]]![[Allemand/Vokabeln - Adjectifs]]

