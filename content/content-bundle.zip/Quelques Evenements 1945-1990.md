#allemand #flashcards/allemand/politique 

| Datum              | —                                                                                     | Ereignis                                |
| ------------------ | ------------------------------------------------------------------------------------- | --------------------------------------- |
| **8 Mai 1945**     | Berlin und Deutschland werden geteilt                                                 | Ende des Zweiten Weltkrieges            |
| **1949**           | Die BRD und die DDR werden gegründet                                                  | Gründung der DDR und der BRD            |
| **1956**           | das ungarische Volk protestieret und wird **niedergeschlagen**                        | Arbeiterproteste in der **DDR**         |
| **13 August 1961** | Strassen, S-Bahnlinien une U-Bahnhöfe zwischen Ost- und Westberlin werden geschlossen | Schliessung der Grenze und **Mauerbau** |
| **26 Juni 1963**   | **John F. Kennedy** spricht an der Berliner Mauer                                     | "Ich bin ein Berliner"                  |
| **1985**           | M. Gorbatschow kommt in der Sowjetunion an die Macht.                                 | Beginn der Reformpolitik im Osten       |
| **Sommer 1989**    | Viele DDR-Bürger sind in die Prager Botschaft und nach Ungarn geflohen                | Botschaftflüchtlinge                    |
| **9 Nov 1989**     | Die Grenze zwischen Ost und West wird geöffnet                                        | **Mauerfall**                           |
| **1 Oktober 1990** | Deutschland ist wieder ein Staat                                                      | Tag der deutschen Wiedervereinigung     |
