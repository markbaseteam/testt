#allemand #conjugaison #flashcards/allemand/conjugaison

# Verbes Réguliers

ich spielte==∅==
<!--SR:!2022-11-15,15,290-->

du *spielte*==st==
<!--SR:!2022-11-17,17,290-->

er spielte==∅==
<!--SR:!2022-11-15,15,290-->

wir *spielte*==n==
<!--SR:!2022-11-16,16,290-->

ihr *spielte*==t==
<!--SR:!2022-11-15,15,290-->

sie *spielte*==n==
<!--SR:!2022-11-13,13,290-->

Sie *spielte*==n==
<!--SR:!2022-11-15,15,290-->

# Verbes Irréguliers

ich *kam*==$\emptyset$==
<!--SR:!2022-11-16,16,300-->

du *kam*_==st==
<!--SR:!2022-11-17,17,300-->

er kam ==∅==
<!--SR:!2022-11-09,9,260-->

wir kam==en==
<!--SR:!2022-11-18,18,300-->

ihr kam==t==
<!--SR:!2022-11-25,23,300-->

sie kam==en==
<!--SR:!2022-11-18,18,300-->

Sie kam==en==
<!--SR:!2022-11-18,18,300-->

# Exercices

## Sigfried

Sigfried (hineingehen) **ging** in den Wald hinein, er (tragen) **trag** ein Schwert und (fühlen) **fühlte** sich damit sehr stark.
<!--SR:!2022-11-12,12,265!2022-12-01,23,312!2022-11-11,7,272-->

Mitten im Wald (sehen) **sah** er einen Treich: das dunkle Wasser (bewegen) **bewegte** sich und Sigfried (kommen) **kam** näher. Da (haben) **hatte** er Angst das wasser (sein) **war** voller Drachen, Schlangen und Kröten.
<!--SR:!2022-11-06,4,292!2022-11-20,13,292!2022-11-06,4,292!2022-11-06,4,292!2022-11-06,4,292-->

Als sie Siegfried (entdecken) **entdeckten**, (herumschlagen) **schlug** sie wild um sich herum, und (versuchen) **versuchte**, ihn zu schnappen.
<!--SR:!2022-11-05,3,272!2022-11-05,3,272!2022-11-22,15,292-->

Aber Sigfried (überlegen) **uberlagte** nicht lange und (beginnen) **begann**, mit seinem Schwert den Bestien die Köpfen abzuschlangen.
<!--SR:!2022-11-05,5,245!2022-11-06,4,292-->

Aber immer wieder (springen) **sprang** ein neues Monster aus dem Wasser. Schliesslich (einfallen) **fiel** etwas ein: er (ausbrechen) **brach** mit seinem starken Arm Baüme aus und (werfen) **warf** sie ins Wasser.
<!--SR:!2022-11-14,14,265!2022-11-08,6,245!2022-11-06,4,292!2022-11-06,4,292-->

Dann (holen) **holte** er bei eineme alten Holzacker in einer Hütte ein Stück brennendes Holz und (anzünden) **zündete** die Bäume auf dem Wasser an und bald (brennen) **brannten** sie.
<!--SR:!2022-11-06,4,292!2022-11-05,3,272!2022-11-05,3,272-->

Alle Ungeheuer (sterben) **starben** in den Flammen.
<!--SR:!2022-11-12,10,265-->

