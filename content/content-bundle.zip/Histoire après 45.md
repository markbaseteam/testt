[[Bundeskanzler seit 1949]]
[[Allemand/Quelques Evenements 1945-1990]]

