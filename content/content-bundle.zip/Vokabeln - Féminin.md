#flashcards/allemand/vokabeln

die Hauptstadt ::: la capitale
<!--SR:!2022-11-04,4,280-->
die Bundesregierung ::: le gouvernement
die Grenze ::: la frontière
die Flagge ::: le drapeau
die Deutschen ::: les allemands
<!--SR:!2022-11-16,16,290-->
die Franzosen ::: les français
<!--SR:!2022-11-13,13,290-->
die Wahl ::: le vote
<!--SR:!2022-11-15,15,290!2022-11-12,12,270-->
die Mauer ::: le mur
die Botschaft ::: l'ambassade
<!--SR:!2022-11-11,11,250!2022-11-12,12,270-->
die Wiedervereinigung ::: la réunification
<!--SR:!2022-11-17,17,290!2022-11-04,4,280-->
die Spannungen ::: les tensions
<!--SR:!2022-11-12,12,270!2022-11-04,4,280-->
die Beziehungen ::: les relations
<!--SR:!2022-11-15,15,290-->
die Besprechung ::: la discussion
<!--SR:!2022-11-05,5,230!2022-11-08,8,250-->
