#flashcards/allemand/vokabeln

das Land (die Länder) ::: le pays
<!--SR:!2022-11-13,13,290-->
das Ministerium ::: le ministère
<!--SR:!2022-11-14,14,290-->
das Wirtschaftsministerium ::: le ministère de l'économie
<!--SR:!2022-11-15,15,290-->
das Ereignis ::: le migrant
<!--SR:!2022-11-05,5,230-->
das Entscheidung ::: la décision
