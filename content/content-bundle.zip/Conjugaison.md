#allemand #conjugaison #flashcards/allemand/conjugaison

# Leçon

[[Verbes Irréguliers]]
[[Conjugaison - Présent]]
[[Conjugaison - Prétérit]]
[[Conjugaison - Parfait]]
[[Conjugaison - Futur]]


# Exercices

reden, 2pp, présent :: Ihr redt
<!--SR:!2022-11-05,3,258-->
kaufen, 2ps, parfait :: Du hast gekauft
<!--SR:!2022-11-06,4,278-->
versuchen, 1pp, prétérit :: Wir versuchten
<!--SR:!2022-11-06,4,278-->
danken, 3ps, prétérit :: Er danktet
<!--SR:!2022-11-12,12,270-->
bilden, 2pp, prétérit :: Ihr bildetet
<!--SR:!2022-11-06,4,278-->
lösen, 3ps, futur :: Er wird lösen
<!--SR:!2022-11-09,7,250-->
erklären, 2pp, parfait :: Er habt erklärt
<!--SR:!2022-11-05,3,258-->
fassen, 2ps, parfait :: Du hast gefasst
<!--SR:!2022-11-14,14,270-->
vor-bereiten, 2pp, plus-que-parfait :: Ihr hattet vorbereitet
<!--SR:!2022-11-06,4,278-->
spielen, 1ps, prétérit :: Ich spielte
<!--SR:!2022-11-06,4,278-->
lernen, 2ps, futur :: Du wirst lernen
<!--SR:!2022-11-06,4,278-->
führen, 2pp, futur :: Ihr werdet führen
<!--SR:!2022-11-15,15,290-->
erlauben, 3ps, parfait :: Er hat erlaubt
<!--SR:!2022-11-05,3,258-->
glauben, 2pp, parfait :: Ihr habt geglaubt
<!--SR:!2022-11-06,4,278-->
leben, 2ps, futur :: Du wirst leben
<!--SR:!2022-11-06,4,278-->
teilen, 2pp, présent :: Ihr teilt
<!--SR:!2022-11-06,4,278-->
handeln, 3pp, prétérit :: Sie handelten
<!--SR:!2022-11-05,3,258-->
stimmen, 1ps, futur :: Ich werde stimmen
<!--SR:!2022-11-13,13,290-->
hoffen, 2pp, prétérit :: Ihr hoftet
<!--SR:!2022-11-06,4,278-->
