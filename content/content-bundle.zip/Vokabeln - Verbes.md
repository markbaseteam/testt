#flashcards/allemand/vokabeln

an/gehören $\lor$ gehören zu $+$ *datif* ::: appartenir à
<!--SR:!2022-11-15,15,290!2022-11-04,4,281-->
sich befinden ::: se trouver
<!--SR:!2022-11-16,16,290!2022-11-15,15,290-->
enthalten ::: contenir
grenzen an ::: être frontalier
<!--SR:!2022-11-13,13,290-->
entsprechen $+$ *datif* ::: correspondre à
<!--SR:!2022-11-04,4,281-->
leiten ::: diriger
wechseln ::: changer
<!--SR:!2022-11-13,13,270!2022-11-04,4,281-->
ändern ::: modifier
<!--SR:!2022-11-16,16,290!2022-11-03,3,261-->
teilen ::: séparer
<!--SR:!2022-11-16,16,290!2022-11-13,13,290-->
bauen ::: construire
<!--SR:!2022-11-15,15,290!2022-11-16,16,290-->
vertreten ::: représenter
<!--SR:!2022-11-01,1,210-->
gründen ::: fonder
<!--SR:!2022-11-15,15,290-->
trümmen ::: ruiner
<!--SR:!2022-11-12,12,270!2022-11-01,1,210-->
stimmen ::: voter pour
<!--SR:!2022-11-14,14,270!2022-11-10,10,250-->
betreffen ::: concerner
dar/stellen ::: constituer
<!--SR:!2022-11-07,7,230!2022-11-07,7,230-->
zu $...$ umformen ::: transformer
<!--SR:!2022-11-02,2,230-->
prägen ::: créer / inventer
fordern ::: réclamer
<!--SR:!2022-11-06,6,230!2022-11-03,3,261-->
trennen ::: séparer
töten ::: tuer
niederschlagen ::: réprimer
<!--SR:!2022-11-13,13,290-->
schlagen ::: frapper
<!--SR:!2022-11-15,15,290!2022-11-16,16,290-->
beginnen ::: commencer
<!--SR:!2022-11-04,4,281-->
flüchten $\equiv$ fliehen ::: fuir
schliessen ::: fermer
<!--SR:!2022-11-06,6,230-->
öffnen ::: ouvrir
<!--SR:!2022-11-14,14,290-->
verletzen ::: blesser
<!--SR:!2022-11-01,1,241-->
schiessen ::: tirer
<!--SR:!2022-11-12,12,270-->
fressen ::: manger (animal)
<!--SR:!2022-11-13,13,290-->
anfangen ::: commencer
liegen ::: se situer / être
<!--SR:!2022-11-02,2,250-->
malen ::: peindre
<!--SR:!2022-11-17,17,290-->
klingeln ::: sonner
<!--SR:!2022-11-02,2,230!2022-11-14,14,270-->
passieren ::: se passer
<!--SR:!2022-11-14,14,270-->
abholen ::: chercher / récupérer
<!--SR:!2022-11-02,2,230!2022-11-02,2,230-->
vergessen ::: oublier
<!--SR:!2022-11-17,17,290!2022-11-17,17,290-->
gefallen ::: plaire
<!--SR:!2022-11-14,14,290!2022-11-04,4,281-->
aufwachsen ::: grandir
<!--SR:!2022-11-10,10,270-->
ziehen ::: tirer 
reisen ::: voyager
<!--SR:!2022-11-09,9,270!2022-11-14,14,290-->
vorbereiten ::: préparer
<!--SR:!2022-11-07,7,230!2022-11-01,1,210-->
handeln ::: agir
<!--SR:!2022-11-13,13,290-->
erlauben ::: permettre
<!--SR:!2022-11-01,1,210!2022-11-03,3,261-->
versuchen ::: essayer
reden ::: parler
spazieren gehen ::: aller randonner
<!--SR:!2022-11-10,10,270!2022-11-17,17,290-->
regnen ::: pleuvoir
