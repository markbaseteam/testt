#flashcards/allemand/grammaire 

|           | Masculin              | Féminin              | Neutre                | Pluriel                    |
| --------- | --------------------- | -------------------- | --------------------- | -------------------------- |
| Nominatif | **ein neuer** Hut     | **eine neue** Hose   | **ein neues** Kleid   | (die) **$\emptyset$** Hüte |
| Accusatif | **einen neuen** Hut   | **eine neue** Hose   | **ein neues Kleid**   | (die) $\emptyset$ Hüte     |
| Datif     | **einem** Hut         | **einer neuen** Hose | **einem neuen Kleid** | (den) **neuen Hüten**      |
| Génitif   | **eines neues Hutes** | **einer neuen Hose**   | **eines neuen Kleides** | (der) **neuen Hüten**      |
<!--SR:!2022-11-05,3,250!2022-11-05,3,250!2022-11-07,3,230!2022-11-06,4,270!2022-11-05,3,250!2022-11-06,4,270!2022-11-05,1,210!2022-11-05,3,250!2022-11-05,1,210!2022-11-05,3,250!2022-11-05,3,250!2022-11-07,3,269!2022-11-05,1,229!2022-11-07,3,269!2022-11-06,2,249-->
