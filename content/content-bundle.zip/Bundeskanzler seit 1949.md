#allemand #politique #flashcards/allemand/politique

# Name: Partei / Jahre

Konrad Adenauer :: CDU / 1949-1963
<!--SR:!2022-11-19,15,250-->
Ludwig Ergard :: CDU / 1963-1966
<!--SR:!2022-11-05,1,210-->
Kurt Goerg Kiesinger :: CDU / 1966-1969
<!--SR:!2022-11-14,10,230-->
Willy Brandt :: SPD / 1969-1974
<!--SR:!2022-11-19,15,250-->
Helmut Schmidt :: SPD / 1974-1982
<!--SR:!2022-11-13,9,230-->
Helmut Kohl :: CDU / 1982-1998
<!--SR:!2022-11-20,16,250-->
Gerhard Schröder :: SPD / 1998-2005
<!--SR:!2022-11-06,2,230-->
Angela Merkel :: CDU / 2005-2021
<!--SR:!2022-12-04,30,290-->
Olaf Scholz :: SPD / seit 2021
<!--SR:!2022-11-07,3,250-->