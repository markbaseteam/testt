#flashcards/allemand/vokabeln

der Bundespräsident ::: le président fédéral
<!--SR:!2022-11-04,4,284-->
der Partei ::: le parti politique
<!--SR:!2022-11-04,4,284-->
der Nachbar ::: le voisin
<!--SR:!2022-11-16,16,290!2022-11-17,17,290-->
der Stadt ::: la ville
<!--SR:!2022-11-17,17,290-->
der Bürger ::: le villageois / l'habitant
<!--SR:!2022-11-17,17,290-->
der Anfang ::: le début
<!--SR:!2022-11-16,16,290!2022-11-14,14,290-->
der Urlaub ::: vacances
<!--SR:!2022-11-12,12,270!2022-11-12,12,270-->
